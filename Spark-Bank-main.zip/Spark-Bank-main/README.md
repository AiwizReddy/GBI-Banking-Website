# Spark-Bank
Download this repo folder as a zip or do a git clone 
https://github.com/bhavinnor1/Spark-Bank/archive/refs/heads/main.zip [1]
Unzip this Folder in your device..

Make Sure Python is installed in your System https://www.python.org/downloads/

then put this commands in the command prompt (pip3 for folks using linux) 

pip install flask

pip install gunicorn 

Navigate to the unzipped folder [1]

open this folder in File Explorer and type cmd in the path bar and press enter

then run app.py by typing 

python app.py 

in your command prompt 

then put this address in your browser 

http://127.0.0.1:8080/

Boom 💥 you got yourself a banking website.

Hosting:-

1. https://dashboard.render.com/register - Sign up here

After Sign up

2. Click on the "+New" button on the dashboard https://dashboard.render.com/

Drop-down appears

3. Then Click on Web Service 

New Web page loads...

4. Then scroll down to "Public Git Repository" input box

Put this link in it https://github.com/bhavinnor1/Spark-Bank 

And Click Continue 

A New Web page loads again

5. Put a name here (it should be unique like a username)

Scroll down to the bottom of the page and click "Create Web Service"

6. Now Wait 3-5 minutes for deployment process to complete

Then Click on the link that is on the screen it will end with ".onrender.com"

💥Boom your website is live on the internet for anyone to see just share the link to anyone

